package com.joshuabutton.documentscanner.document;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;

import android.support.v7.app.AlertDialog;
import android.support.v7.view.menu.MenuBuilder;
import android.support.v7.view.menu.MenuPopupHelper;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.PopupMenu;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import com.google.android.gms.ads.AdRequest;
import com.gpaddy.hungdh.base.BaseActivity;
import com.gpaddy.hungdh.camscanner.MainActivity;
import com.gpaddy.hungdh.listdoc.DocsActivity;
import com.gpaddy.hungdh.util.Const;
import com.gpaddy.hungdh.util.ImageUtils;
import com.joshuabutton.documentscanner.activities.SimpleDocumentScannerActivity;
import com.joshuabutton.documentscanner.handle.HandleActivity;
import com.joshuabutton.documentscanner.process.view.ProcessImageActivity;
import com.todobom.opennotescanner.R;

import java.io.File;

import butterknife.BindView;
import butterknife.OnClick;

import static com.gpaddy.hungdh.camscanner.MainActivity.mInterstitialAd;
import static com.gpaddy.hungdh.util.Ads.showAds;
import static com.gpaddy.hungdh.util.PathUtil.getLstImagePath;

public class DocumentActivity extends BaseActivity implements DocumentContract.DocumentView {
    private DocumentContract.IDocumentPresenter presenter;
    private DocumentAdapter adapter;
    @BindView(R.id.rcView)
    RecyclerView rcView;
    @BindView(R.id.imgBack)
    ImageView imgBack;
    @BindView(R.id.imgMenu)
    ImageView imgMenu;
    @BindView(R.id.edtName)
    EditText editName;
    @BindView(R.id.imgDone)
    ImageView imgDone;
    @BindView(R.id.tvName)
    TextView tvName;
    private String folder;
    private static final int TYPE_NEW_CREATE = 1;
    private int type = 0;
    public static final int REQUEST_IMPORT = 100;

    @Override
    protected int getLayoutRes() {
        return R.layout.activity_document;
    }

    @Override
    protected void initData() {
        folder = getIntent().getStringExtra("folder");
        try {
            type = (int) getIntent().getSerializableExtra("type");
        } catch (Exception e) {
            type = TYPE_NEW_CREATE;
        }
        adapter.loadData(presenter.getListDocument(folder));
        File file = new File(folder);
        if (type == TYPE_NEW_CREATE) {
            editName.setVisibility(View.VISIBLE);
            imgDone.setVisibility(View.VISIBLE);
            tvName.setVisibility(View.GONE);
            imgMenu.setVisibility(View.GONE);
            editName.setText(file.getName());
            setNameFile(file.getName());
            editName.setSelection(editName.getText().toString().length());
        } else {
            imgDone.setVisibility(View.GONE);
            editName.setVisibility(View.GONE);
            tvName.setVisibility(View.VISIBLE);
            imgMenu.setVisibility(View.VISIBLE);
            tvName.setText(file.getName());
        }


    }

    @Override
    protected void initView() {
        getSupportActionBar().hide();

        presenter = new DocumentPresenter(this, this);
        rcView.setLayoutManager(new GridLayoutManager(this, 2));
        adapter = new DocumentAdapter(this, presenter);
        rcView.setAdapter(adapter);
    }

    @Override
    public void onItemClick(int position) {
        HandleActivity.startHandle(DocumentActivity.this, position, folder);
    }

    @Override
    public String getDefaultName() {
        return folder;
    }

    @Override
    public void setFolderName(String folderName) {
        this.folder = folderName;
    }

    @Override
    public void setNameFile(String nameFile) {
        tvName.setText(nameFile);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMPORT && resultCode == RESULT_OK) {
            adapter.loadData(presenter.getListDocument(folder));
        }
    }

    @Override
    protected void onResume() {
        adapter.loadData(presenter.getListDocument(folder));
        super.onResume();
    }

    @OnClick(R.id.imgBack)
    public void onBack() {
        startActivity(new Intent(DocumentActivity.this, MainActivity.class));
//        onBackPressed();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @SuppressLint("RestrictedApi")
    @OnClick(R.id.imgMenu)
    public void onMenu() {
        PopupMenu pop = new PopupMenu(this, imgMenu);
        pop.getMenuInflater().inflate(R.menu.menu_doc, pop.getMenu());

        pop.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                final File file = new File(folder);
                switch (menuItem.getItemId()) {
                    case R.id.menuRename:
                        showDialog();
                        break;
                    case R.id.menuImport:
                        SimpleDocumentScannerActivity.startScanner(DocumentActivity.this, "", folder);
                        break;
                    case R.id.menuOpen:
                        presenter.openWith(getDefaultName() + "/" + tvName.getText().toString() + ".pdf");
                        break;
                    case R.id.menuShare:
                        presenter.shareFile(getDefaultName() + "/" + tvName.getText().toString() + ".pdf");
                        break;
                    case R.id.menuSaveToPDF:
                        String pdfName = file.getName() + ".pdf";
                        ImageUtils.convertImageToPdf(getLstImagePath(folder), folder + "/" + pdfName, DocumentActivity.this);
                        break;
                    case R.id.menuDelete:
                        if (file.exists()) {
                            final android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(DocumentActivity.this);
                            builder
                                    .setMessage("Delete this document folder?")
                                    .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialogInterface, int i) {
                                            for (File file1 : file.listFiles())
                                                file1.delete();
                                            file.delete();
                                            Toast.makeText(DocumentActivity.this, "Deleted", Toast.LENGTH_LONG).show();
                                            adapter.notifyDataSetChanged();
                                        }
                                    })
                                    .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialogInterface, int i) {
                                            dialogInterface.dismiss();

                                        }
                                    });
                            final android.app.AlertDialog alertDialog = builder.create();
                            alertDialog.show();
                        }
                }
                return true;
            }
        });
        MenuPopupHelper menuHelper = new MenuPopupHelper(this, (MenuBuilder) pop.getMenu(), imgMenu);
        menuHelper.setForceShowIcon(true);
        menuHelper.show();
    }

    @OnClick(R.id.imgDone)
    public void onDone() {
        String filePdfName = editName.getText().toString();
        presenter.reName(filePdfName);
        Const.hideKeyboardFrom(DocumentActivity.this, editName);
        imgDone.setVisibility(View.GONE);
        editName.setVisibility(View.GONE);
        tvName.setVisibility(View.VISIBLE);
        imgMenu.setVisibility(View.VISIBLE);

        showAds(getApplicationContext());
    }

    private void showDialog() {
        LayoutInflater layoutInflaterAndroid = LayoutInflater.from(this);
        View mView = layoutInflaterAndroid.inflate(R.layout.dialog_rename, null);
        AlertDialog.Builder alertDialogBuilderUserInput = new AlertDialog.Builder(this);
        alertDialogBuilderUserInput.setView(mView);

        final EditText userInputDialogEditText = (EditText) mView.findViewById(R.id.userInputDialog);
        userInputDialogEditText.setText(tvName.getText().toString());
        alertDialogBuilderUserInput
                .setCancelable(false)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialogBox, int id) {
                        presenter.reName(userInputDialogEditText.getText().toString());
                    }
                })

                .setNegativeButton("Cancel",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialogBox, int id) {
                                dialogBox.cancel();
                            }
                        });

        AlertDialog alertDialogAndroid = alertDialogBuilderUserInput.create();
        alertDialogAndroid.show();
    }


}

