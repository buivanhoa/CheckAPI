package com.joshuabutton.documentscanner.document;

import com.gpaddy.hungdh.util.Const;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Phí Văn Tuấn on 30/11/2018.
 */

public class DocumentModel implements Serializable {
    private String path;

    public DocumentModel(String path) {
        this.path = path;
    }

    public DocumentModel() {

    }

    public String getPath() {
        return path;
    }

    public List<DocumentModel> getLstPathImage(String folder) {
        List<DocumentModel> lst = new ArrayList<>();
        File file = new File(folder);
        if (file.exists()) {
            for (File f : file.listFiles()) {
                try {
                    if (f.getAbsolutePath().endsWith(".jpg")) {
                        lst.add(new DocumentModel(f.getAbsolutePath()));
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        return lst;
    }

    public List<DocumentModel> getLstDocs(String folder) {
        List<DocumentModel> lst = new ArrayList<>();
        File file = new File(folder);
        if (file.exists()) {
            for (File f : file.listFiles()) {
                try {
                    if (f.exists() && f.isDirectory()) {
                        lst.add(new DocumentModel(f.getAbsolutePath()));
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        return lst;
    }
}
