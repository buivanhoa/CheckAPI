package com.joshuabutton.documentscanner.process.view;

import com.joshuabutton.documentscanner.process.model.FilterModel;

/**
 * Created by Phí Văn Tuấn on 24/11/2018.
 */

public interface IProcessView {
    void onItemClick(FilterModel adjuster);
}
