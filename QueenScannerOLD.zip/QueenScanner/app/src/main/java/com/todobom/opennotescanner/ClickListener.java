package com.todobom.opennotescanner;

public interface ClickListener {
    void onClick(int index);

    void onLongClick(int index);
}
